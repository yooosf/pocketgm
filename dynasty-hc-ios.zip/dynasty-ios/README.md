# Dynasty HC — iOS App Store Build Guide

This folder contains everything needed to turn the Dynasty HC web game into a
native iOS app you can submit to the App Store, using **Capacitor** (the standard
tool for wrapping a web app in a native shell).

The game itself is unchanged — it lives in `www/index.html` and runs offline inside
the native app, saving to local storage just like before.

---

## What you need first (no way around these — they're Apple's rules)

1. **A Mac** with macOS. (Xcode only runs on macOS. If you don't have a Mac, see
   "No Mac?" at the bottom.)
2. **Xcode** — free from the Mac App Store. After installing, open it once and let
   it install components, then run `xcode-select --install` in Terminal.
3. **Node.js** — download the LTS version from https://nodejs.org
4. **An Apple Developer account** — $99/year at https://developer.apple.com/programs/
   Required to put any app on the App Store.

---

## Step-by-step

Open **Terminal** and `cd` into this folder, then run the commands in order.

### 1. Install the tools
```bash
npm install
```

### 2. Initialize Capacitor
A `capacitor.config.json` is already included. If `npm install` didn't pick it up,
you can (re)create it with:
```bash
npx cap init "Dynasty HC" com.yourname.dynastyhc --web-dir=www
```
**Change `com.yourname.dynastyhc`** to your own reverse-domain bundle ID (e.g.
`com.jsmith.dynastyhc`). This must be unique and match what you register in Apple's
Developer portal. Edit it in `capacitor.config.json` too.

### 3. Add the iOS platform
```bash
npx cap add ios
```
This creates an `ios/` folder containing a real Xcode project.

### 4. Copy the game into the native project
```bash
npx cap sync ios
```
Run this again any time you change `www/index.html`.

### 5. Open it in Xcode
```bash
npx cap open ios
```

### 6. Configure signing & icons in Xcode
- In the left sidebar, click the blue **App** project → **Signing & Capabilities**.
- Check **"Automatically manage signing"** and pick your **Team** (your Apple
  Developer account). Xcode handles the certificates for you.
- Set the app icon: in the sidebar open **App → Assets.xcassets → AppIcon**, then
  drag `icon-1024-appstore.png` from this folder onto the 1024pt "App Store" slot.
  (Xcode 14+ only needs the single 1024 icon and generates the rest.)
- Optional: set the **Display Name** to "Dynasty HC" under the General tab.

### 7. Test it
- Pick a simulator (e.g. iPhone 15) from the top bar and press the ▶ **Run** button.
  The game should boot in the simulator. Try it on a real iPhone too (plug it in,
  select it as the run target, trust the developer profile on the device).

### 8. Submit to the App Store
- In Xcode's top device dropdown choose **"Any iOS Device (arm64)"**.
- Menu: **Product → Archive**. When it finishes, the Organizer window opens.
- Click **Distribute App → App Store Connect → Upload**.
- Go to https://appstoreconnect.apple.com, create a new app record (same bundle ID),
  fill in name, description, screenshots, age rating, and privacy info, then select
  your uploaded build and **Submit for Review**.

Apple review typically takes 1–3 days.

---

## App Store listing tips

- **Screenshots**: required. Run the app in the iPhone simulator, play to a few good
  screens (hub, a game, recruiting, stat leaders), and use **Cmd+S** in the simulator
  to save screenshots. You need sizes for 6.7" and 6.5" iPhones at minimum.
- **Privacy**: the game collects no data and has no accounts — choose "Data Not
  Collected" in the privacy questionnaire. It's all local.
- **Avoiding rejection**: Apple sometimes rejects apps that are "just a website."
  A fully offline, self-contained game like this usually passes. If you want extra
  safety, you can add native touches later (haptics via `@capacitor/haptics`, a
  native share sheet, etc.) — ask and I can wire those in.

---

## Files in this folder

| File | What it is |
|---|---|
| `www/index.html` | The complete game (with iOS safe-area + web-app tweaks added) |
| `www/manifest.json` | PWA manifest (also makes it installable from the web) |
| `capacitor.config.json` | Capacitor settings (app name, bundle ID, web dir) |
| `package.json` | Node dependencies for Capacitor |
| `icon.svg` | Source app icon |
| `icon-1024-appstore.png` | **Use this one in Xcode** (flattened, no transparency) |
| `icon-1024/512/192/180.png` | Icon sizes for PWA / Apple touch icon |
| `.gitignore` | Standard ignores |

---

## No Mac? Three options

1. **Rent a Mac in the cloud** — services like MacStadium or MacinCloud give you a
   remote Mac you can run Xcode on for a monthly fee.
2. **PWABuilder** — https://www.pwabuilder.com — host the `www/` folder anywhere
   (e.g. Netlify), paste the URL, and it generates an iOS package for you. You still
   need the $99 Apple account and a Mac (or cloud Mac) to do the final upload, but it
   removes most of the Xcode work.
3. **Ship it as a PWA instead** — the included `manifest.json` already makes the game
   installable. Deploy `www/` to Netlify (drag the folder onto netlify.com/drop),
   open the URL in Safari on iPhone, tap Share → "Add to Home Screen." It installs
   like an app, runs full-screen and offline — just not listed in the App Store. Free,
   no Apple account needed.

---

## Updating the game later

1. Replace `www/index.html` with the new version.
2. `npx cap sync ios`
3. In Xcode, bump the **Build** number (and **Version** for a new release), then
   Archive → Distribute again.
